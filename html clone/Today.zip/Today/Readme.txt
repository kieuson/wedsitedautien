đăng ký tài khoản dribbble.com
đăng ký tài khoản fontawesome.com để phục vụ cho html

SS17,SS18(sử dụng css để căn chỉnh form)

SS19 xây dựng bố cục layout cho 1 trang web

SS20 tương đối và tuyệt đối